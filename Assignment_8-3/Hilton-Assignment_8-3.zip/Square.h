#pragma once
#include "Polygon.h"
class Square : public Polygon
{
public:
	unsigned int nSides = 4;
	// Inherited via BaseObject
};

